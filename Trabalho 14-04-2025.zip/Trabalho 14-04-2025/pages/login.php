<?php
session_start();

// Usuários e senhas (senha simples sem hash)
$usuarios = [
    'admin' => '123'
];

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['usuario'] ?? '';
    $senha = $_POST['senha'] ?? '';

    if (isset($usuarios[$usuario]) && $usuarios[$usuario] === $senha) {
        $_SESSION['usuario'] = $usuario;
        header('Location: index.php');
        exit;
    } else {
        $erro = 'Usuário ou senha inválidos.';
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<link rel="stylesheet" href="css/style.css">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Artesanato</title>
    <link rel="stylesheet" href="../Css/login.css">
</head>
<body>

<div class="login-container">
    <h2>Login</h2>
    <?php if ($erro): ?>
        <p class="error-message"><?php echo $erro; ?></p>
    <?php endif; ?>
    <form method="POST" class="form">
        <input type="text" name="usuario" placeholder="Usuário" required class="input-field">
        <input type="password" name="senha" placeholder="Senha" required class="input-field">
        <button type="submit" class="btn">Entrar</button>
    </form>
</div>

</body>
</html>
