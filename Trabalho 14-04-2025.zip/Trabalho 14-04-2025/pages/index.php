<?php include 'protecao.php'; ?>


<?php
$itens = [
    1 => ['titulo' => 'Bordado', 'categoria' => 'Artesanato', 'imagem' => 'imagens/bordado.webp'],
    2 => ['titulo' => 'Crochê', 'categoria' => 'Artesanato', 'imagem' => 'imagens/croche.jpg'],
    3 => ['titulo' => 'Tricô', 'categoria' => 'Artesanato', 'imagem' => 'imagens/trico.jpg'],
    4 => ['titulo' => 'Tecidos', 'categoria' => 'Vestimenta', 'imagem' => 'imagens/tecidos.jpg'],
];

function exibirItens($itens) {
    foreach ($itens as $id => $item) {
        echo "<div class='item'>
                <img src='{$item['imagem']}' alt='{$item['titulo']}'>
                <h3>{$item['titulo']}</h3>
                <p>Categoria: {$item['categoria']}</p>
                <a href='detalhes.php?id={$id}'>Ver mais</a>
              </div>";
    }
}

$categoriaFiltro = isset($_GET['categoria']) ? $_GET['categoria'] : '';

function filtrarItens($itens, $categoriaFiltro) {
    if ($categoriaFiltro) {
        return array_filter($itens, function($item) use ($categoriaFiltro) {
            return $item['categoria'] === $categoriaFiltro;
        });
    }
    return $itens;
}

$itensFiltrados = filtrarItens($itens, $categoriaFiltro);
?>

<!DOCTYPE html>
<html lang="pt-br">
<link rel="stylesheet" href="css/style.css">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catálogo Artesanal</title>
    <link rel="stylesheet" href="../Css/index.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>

<header class="header">
    <h1>Catálogo Artesanal</h1>
    <a href="logout.php">Sair</a>

</header>

<form method="GET" action="index.php">
    <label for="categoria">Filtrar por Categoria:</label>
    <select name="categoria" id="categoria">
        <option value="">Todas as Categorias</option>
        <option value="Artesanato" <?php echo ($categoriaFiltro === 'Artesanato') ? 'selected' : ''; ?>>Artesanato</option>
        <option value="Vestimenta" <?php echo ($categoriaFiltro === 'Vestimenta') ? 'selected' : ''; ?>>Vestimenta</option>
    </select>
    <button type="submit">Filtrar</button>
</form>

<div class="catalogo">
    <?php exibirItens($itensFiltrados); ?>
</div>

</body>
</html>
