<?php
$itens = [
    1 => ['titulo' => 'Bordado', 'categoria' => 'Artesanato', 'imagem' => 'witcher3.jpg'],
    2 => ['titulo' => 'Crochê', 'categoria' => 'Artesanato', 'imagem' => 'minecraft.jpg'],
    3 => ['titulo' => 'Trico', 'categoria' => 'Artesanato', 'imagem' => 'fifa21.jpg'],
    4 => ['titulo' => 'Tecidos', 'categoria' => 'Vestimenta', 'imagem' => 'lol.jpg'],
];

$categoria = isset($_GET['categoria']) ? $_GET['categoria'] : '';

$itensFiltrados = array_filter($itens, function($item) use ($categoria) {
    return !$categoria || $item['categoria'] === $categoria;
});

function exibirItens($itens) {
    foreach ($itens as $id => $item) {
        echo "<div class='item'>
                <img src='imagens/{$item['imagem']}' alt='{$item['titulo']}' />
                <h3>{$item['titulo']}</h3>
                <p>Categoria: {$item['categoria']}</p>
                <a href='detalhes.php?id={$id}'>Ver mais</a>
              </div>";
}
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Filtrar Jogos</title>
</head>
<body>

    <h1>Filtrar Jogos por Categoria</h1>

    <form method="GET" action="filtrar.php">
        <label for="categoria">Categoria:</label>
        <select name="categoria" id="categoria">
            <option value="">Selecione</option>
            <option value="Artesanato">RPG</option>
            <option value="Artesanato">Artesanato</option>
            <option value="Artesanato">Artesanato</option>
            <option value="Artesanato">Artesanato</option>
        </select>
        <button type="submit">Filtrar</button>
    </form>

    <div class="catalogo">
        <?php exibirItens($itensFiltrados); ?>
    </div>

</body>
</html>
