<?php
session_start();

// Verificação de login
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}

$itens = [
    1 => [
        'titulo' => 'Bordado', 
        'categoria' => 'Artesanato', 
        'imagem' => 'bordado.webp',
        'descricao' => 'O bordado é uma técnica manual que transforma tecidos simples em verdadeiras obras de arte com agulhas e linhas.'
    ],
    2 => [
        'titulo' => 'Crochê', 
        'categoria' => 'Artesanato', 
        'imagem' => 'croche.jpg',
        'descricao' => 'O crochê é uma arte que une fios e criatividade, criando peças únicas para decoração ou uso pessoal.'
    ],
    3 => [
        'titulo' => 'Tricô', 
        'categoria' => 'Artesanato', 
        'imagem' => 'trico.jpg',
        'descricao' => 'O tricô é uma técnica clássica de entrelaçamento de fios, perfeita para criar mantas, roupas e acessórios.'
    ],
    4 => [
        'titulo' => 'Tecidos', 
        'categoria' => 'Vestimenta', 
        'imagem' => 'tecidos.jpg',
        'descricao' => 'Tecidos são a base para diversas criações artesanais, possibilitando costura, personalização e design têxtil.'
    ],
];

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$item = $itens[$id] ?? null;

if (!$item) {
    echo "<p style='font-family: Poppins, sans-serif; color: darkred;'>Item não encontrado! Volte ao <a href='index.php'>catálogo</a>.</p>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($item['titulo']); ?> - Detalhes</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/style.css">

</head>
<body>

<header class="header">
    <h1>Detalhes do Artesanato</h1>
</header>

<main class="detalhes">
    <img src="imagens/<?php echo htmlspecialchars($item['imagem']); ?>" alt="<?php echo htmlspecialchars($item['titulo']); ?>" />
    <h2><?php echo htmlspecialchars($item['titulo']); ?></h2>
    <p><strong>Categoria:</strong> <?php echo htmlspecialchars($item['categoria']); ?></p>
    <p><strong>Descrição:</strong> <?php echo htmlspecialchars($item['descricao']); ?></p>
    <a href="index.php" class="btn-voltar">← Voltar ao Catálogo</a>
</main>

</body>

</html>
